function appendToDisplay(value) {
    document.getElementById("display").value += value;
  }
  
  function calculate() {
    let displayValue = document.getElementById("display").value;
    try {
      let result = eval(displayValue);
      document.getElementById("display").value = result;
    } catch (error) {
      document.getElementById("display").value = "Error";
    }
  }
  
  function clearDisplay() {
    document.getElementById("display").value = "";
  }
   
  
  
  
  
  
  